



const Contact=()=>{

    return(
        <>
        contact us here
        </>
    )

}


export default Contact;