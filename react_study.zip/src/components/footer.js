


const Footer=()=>{
    return(
        <>
        <p className="bg-dark mt-3 text-white">this is and footer</p>
        </>
    )
}


export default Footer;