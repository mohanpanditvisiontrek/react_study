import { createContext } from "react";

const mycontext = createContext(null);

export default mycontext;